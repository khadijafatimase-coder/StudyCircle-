// REGISTER FORM VALIDATION

const registerForm = document.getElementById("registerForm");

if (registerForm) {

    registerForm.addEventListener("submit", function(event) {

        event.preventDefault();

        let name = document.getElementById("name").value.trim();
        let email = document.getElementById("email").value.trim();
        let password = document.getElementById("password").value;
        let confirmPassword = document.getElementById("confirmPassword").value;

        let message = document.getElementById("registerMessage");

        if (name === "" || email === "" || password === "" || confirmPassword === "") {
            message.textContent = "Please fill in all fields.";
            message.style.color = "red";
            return;
        }

        if (password.length < 6) {
            message.textContent = "Password must contain at least 6 characters.";
            message.style.color = "red";
            return;
        }

        if (password !== confirmPassword) {
            message.textContent = "Passwords do not match.";
            message.style.color = "red";
            return;
        }

        message.textContent = "Registration successful!";
        message.style.color = "green";

    });
}


// LOGIN FORM VALIDATION

const loginForm = document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", function(event) {

        event.preventDefault();

        let email = document.getElementById("loginEmail").value.trim();
        let password = document.getElementById("loginPassword").value;

        let message = document.getElementById("loginMessage");

        if (email === "" || password === "") {
            message.textContent = "Please enter email and password.";
            message.style.color = "red";
            return;
        }

        message.textContent = "Login successful!";
        message.style.color = "green";

    });
}


// JOIN STUDY GROUP BUTTON

function joinGroup(button) {

    button.textContent = "Joined ✓";
    button.disabled = true;

}


// SEARCH FUNCTION

function searchResources() {

    let search = document
        .getElementById("searchInput")
        .value
        .toLowerCase();

    let cards = document.querySelectorAll(".resource-card");

    cards.forEach(function(card) {

        let text = card.textContent.toLowerCase();

        if (text.includes(search)) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }

    });

}


// CATEGORY FILTER

function filterResources() {

    let category = document.getElementById("categoryFilter").value;

    let cards = document.querySelectorAll(".resource-card");

    cards.forEach(function(card) {

        let cardCategory = card.getAttribute("data-category");

        if (category === "all" || cardCategory === category) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }

    });

}


// LOGOUT

function logout() {

    alert("You have been logged out.");

    window.location.href = "login.html";

}